package com.nawabbangles.shop;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    LinearLayout root, productList;
    TextView cartText;
    int cartCount = 0;
    int total = 0;

    String[] names = {
        "Royal Red Bangles", "Golden Bridal Set", "Pink Stone Bangles",
        "Green Traditional Set", "Black Party Bangles", "Pearl Designer Set"
    };
    int[] prices = {299, 799, 399, 499, 349, 899};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildHome();
    }

    TextView tv(String text, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(45, 25, 35));
        t.setPadding(20, 14, 20, 14);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(142, 36, 80));
        return b;
    }

    void buildHome() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 24);
        root.setBackgroundColor(Color.rgb(255, 248, 251));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = tv("Nawab Bangles Shop", 28, true);
        title.setTextColor(Color.rgb(142, 36, 80));
        root.addView(title);

        TextView sub = tv("✨ Beautiful bangles for every occasion", 16, false);
        root.addView(sub);

        cartText = tv("🛒 Cart: 0 items   |   ₹0", 17, true);
        root.addView(cartText);

        TextView heading = tv("Our Collection", 22, true);
        heading.setPadding(20, 28, 20, 10);
        root.addView(heading);

        productList = new LinearLayout(this);
        productList.setOrientation(LinearLayout.VERTICAL);
        root.addView(productList);

        for (int i = 0; i < names.length; i++) addProduct(i);

        Button checkout = button("🛍️ View Cart & Checkout");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(10, 24, 10, 10);
        root.addView(checkout, cp);
        checkout.setOnClickListener(v -> showCart());

        TextView contact = tv("📞 Order help: Contact the shop owner", 15, false);
        root.addView(contact);
        contact.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:0000000000"));
            startActivity(intent);
        });
    }

    void addProduct(int i) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 14, 16, 14);
        card.setBackgroundColor(Color.WHITE);

        TextView n = tv("💍 " + names[i], 19, true);
        TextView p = tv("₹" + prices[i], 17, false);
        Button add = button("Add to Cart");

        card.addView(n);
        card.addView(p);
        card.addView(add);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(4, 8, 4, 8);
        productList.addView(card, lp);

        final int index = i;
        add.setOnClickListener(v -> {
            cartCount++;
            total += prices[index];
            updateCart();
            Toast.makeText(this, names[index] + " added to cart", Toast.LENGTH_SHORT).show();
        });
    }

    void updateCart() {
        cartText.setText("🛒 Cart: " + cartCount + " items   |   ₹" + total);
    }

    void showCart() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Nawab Bangles Shop - Cart");
        if (cartCount == 0) {
            dialog.setMessage("Your cart is empty.");
        } else {
            dialog.setMessage("Items: " + cartCount + "\nTotal: ₹" + total +
                    "\n\nPress PLACE ORDER to contact the shop.");
            dialog.setPositiveButton("PLACE ORDER", (d, w) -> {
                Intent send = new Intent(Intent.ACTION_SENDTO);
                send.setData(Uri.parse("smsto:0000000000"));
                send.putExtra("sms_body", "Nawab Bangles Shop order: " +
                        cartCount + " items, total ₹" + total);
                try { startActivity(send); }
                catch (Exception e) {
                    Toast.makeText(this, "Please set a messaging app first.", Toast.LENGTH_LONG).show();
                }
            });
        }
        dialog.setNegativeButton("CLOSE", null);
        dialog.show();
    }
}

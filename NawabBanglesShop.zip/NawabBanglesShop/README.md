# Nawab Bangles Shop

A simple Android shopping app for a bangles shop.

Features:
- Product collection
- Add to cart
- Cart total
- Basic checkout/order message
- Shop name: Nawab Bangles Shop

Open this project in Android Studio and run it on an Android phone/emulator.

Before publishing, replace the demo phone number `0000000000` in `MainActivity.java` with the shop's real order number.
